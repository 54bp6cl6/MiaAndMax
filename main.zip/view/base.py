from linebot.models import TextSendMessage

def TextMessage(text):
    return TextSendMessage(text)